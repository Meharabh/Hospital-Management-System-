# Hospital-Management-System
This is basic web application for the hospital management system.
This project is done by
<br>
  1.Rishi Raj.G<br>
  2.Vikkram Adithya.K<br>
  3.Rishi Kumar.R<br>
 <br>
We've developed this Hospital management system as my mini project in my first year of UG to maintain the patient records, manage appointments and various other needs of the hospital. This project made me to learn many new stuffs like SQL, PHP etc.. <a href="https://rishi772001.github.io/Hospital-Management-System/">Click here</a> to view front end for this project.
